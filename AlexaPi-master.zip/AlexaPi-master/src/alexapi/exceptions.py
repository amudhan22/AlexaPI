
class ConfigurationException(Exception):
	pass
