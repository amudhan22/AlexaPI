

class RequestType:
	STARTED = 'STARTED'
	INTERRUPTED = 'INTERRUPTED'
	FINISHED = 'FINISHED'
	ERROR = 'ERROR'

	def __init__(self):
		pass



class PlayerActivity:
	PLAYING = 'PLAYING'
	PAUSED = 'PAUSED'
	IDLE = 'IDLE'

	def __init__(self):
		pass
